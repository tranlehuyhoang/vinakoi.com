<div>
    <div id="button-contact-vr" class="">
        <div id="gom-all-in-one"><!-- v3 -->











            <!-- zalo -->
            <div id="zalo-vr" class="button-contact">
                <div class="phone-vr">
                    <div class="phone-vr-circle-fill"></div>
                    <div class="phone-vr-img-circle">
                        <a target="_blank" href="https://zalo.me/0999999999">
                            <img alt="Zalo" src="/assets/wp-content/plugins/button-contact-vr/img/zalo.png" />
                        </a>
                    </div>
                </div>
            </div>
            <!-- end zalo -->


            <!-- Phone -->
            <div id="phone-vr" class="button-contact">
                <div class="phone-vr">
                    <div class="phone-vr-circle-fill"></div>
                    <div class="phone-vr-img-circle">
                        <a href="tel:0999999999">
                            <img alt="Phone" src="/assets/wp-content/plugins/button-contact-vr/img/phone.png" />
                        </a>
                    </div>
                </div>
            </div>
            <!-- end phone -->

        </div><!-- end v3 class gom-all-in-one -->


    </div>
    <!-- popup form -->
    <div id="popup-form-contact-vr">
        <div class="bg-popup-vr"></div>
        <div class="content-popup-vr" id="loco-" style=" ">

            <div class="content-popup-div-vr">

            </div>


            <div class="close-popup-vr">x</div>
        </div>
    </div>

    <!-- Add custom css and js -->
    <style type="text/css">
    </style>
    <!-- end Add custom css and js -->
    <!-- popup showroom -->
    <div id="popup-showroom-vr">
        <div class="bg-popup-vr"></div>
        <div class="content-popup-vr" id="loco-" style=" ">

            <div class="content-popup-div-vr">

            </div>
            <div class="close-popup-vr">x</div>
        </div>
    </div>
</div>
