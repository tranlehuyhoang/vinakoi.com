<div data-elementor-type="footer" data-elementor-id="321"
class="elementor elementor-321 elementor-location-footer" data-elementor-post-type="elementor_library">
<section
    class="elementor-section elementor-top-section elementor-element elementor-element-7372fcc elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="7372fcc" data-element_type="section"
    data-settings="{&quot;jet_parallax_layout_list&quot;:[]}">
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-86a3960"
            data-id="86a3960" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-b7ac719 elementor-widget elementor-widget-heading"
                    data-id="b7ac719" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <span class="elementor-heading-title elementor-size-default">Mới Nhất</span>
                    </div>
                </div>
                <div class="elementor-element elementor-element-60bf37a elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                    data-id="60bf37a" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <style>
                            /*! elementor - v3.20.0 - 11-03-2024 */
                            .elementor-widget-divider {
                                --divider-border-style: none;
                                --divider-border-width: 1px;
                                --divider-color: #0c0d0e;
                                --divider-icon-size: 20px;
                                --divider-element-spacing: 10px;
                                --divider-pattern-height: 24px;
                                --divider-pattern-size: 20px;
                                --divider-pattern-url: none;
                                --divider-pattern-repeat: repeat-x
                            }

                            .elementor-widget-divider .elementor-divider {
                                display: flex
                            }

                            .elementor-widget-divider .elementor-divider__text {
                                font-size: 15px;
                                line-height: 1;
                                max-width: 95%
                            }

                            .elementor-widget-divider .elementor-divider__element {
                                margin: 0 var(--divider-element-spacing);
                                flex-shrink: 0
                            }

                            .elementor-widget-divider .elementor-icon {
                                font-size: var(--divider-icon-size)
                            }

                            .elementor-widget-divider .elementor-divider-separator {
                                display: flex;
                                margin: 0;
                                direction: ltr
                            }

                            .elementor-widget-divider--view-line_icon .elementor-divider-separator,
                            .elementor-widget-divider--view-line_text .elementor-divider-separator {
                                align-items: center
                            }

                            .elementor-widget-divider--view-line_icon .elementor-divider-separator:after,
                            .elementor-widget-divider--view-line_icon .elementor-divider-separator:before,
                            .elementor-widget-divider--view-line_text .elementor-divider-separator:after,
                            .elementor-widget-divider--view-line_text .elementor-divider-separator:before {
                                display: block;
                                content: "";
                                border-block-end: 0;
                                flex-grow: 1;
                                border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
                            }

                            .elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                flex-grow: 0;
                                flex-shrink: 100
                            }

                            .elementor-widget-divider--element-align-left .elementor-divider-separator:before {
                                content: none
                            }

                            .elementor-widget-divider--element-align-left .elementor-divider__element {
                                margin-left: 0
                            }

                            .elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                flex-grow: 0;
                                flex-shrink: 100
                            }

                            .elementor-widget-divider--element-align-right .elementor-divider-separator:after {
                                content: none
                            }

                            .elementor-widget-divider--element-align-right .elementor-divider__element {
                                margin-right: 0
                            }

                            .elementor-widget-divider--element-align-start .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type {
                                flex-grow: 0;
                                flex-shrink: 100
                            }

                            .elementor-widget-divider--element-align-start .elementor-divider-separator:before {
                                content: none
                            }

                            .elementor-widget-divider--element-align-start .elementor-divider__element {
                                margin-inline-start: 0
                            }

                            .elementor-widget-divider--element-align-end .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type {
                                flex-grow: 0;
                                flex-shrink: 100
                            }

                            .elementor-widget-divider--element-align-end .elementor-divider-separator:after {
                                content: none
                            }

                            .elementor-widget-divider--element-align-end .elementor-divider__element {
                                margin-inline-end: 0
                            }

                            .elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator {
                                border-block-start: var(--divider-border-width) var(--divider-border-style) var(--divider-color)
                            }

                            .elementor-widget-divider--separator-type-pattern {
                                --divider-border-style: none
                            }

                            .elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,
                            .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,
                            .elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,
                            .elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator {
                                width: 100%;
                                min-height: var(--divider-pattern-height);
                                -webkit-mask-size: var(--divider-pattern-size) 100%;
                                mask-size: var(--divider-pattern-size) 100%;
                                -webkit-mask-repeat: var(--divider-pattern-repeat);
                                mask-repeat: var(--divider-pattern-repeat);
                                background-color: var(--divider-color);
                                -webkit-mask-image: var(--divider-pattern-url);
                                mask-image: var(--divider-pattern-url)
                            }

                            .elementor-widget-divider--no-spacing {
                                --divider-pattern-size: auto
                            }

                            .elementor-widget-divider--bg-round {
                                --divider-pattern-repeat: round
                            }

                            .rtl .elementor-widget-divider .elementor-divider__text {
                                direction: rtl
                            }

                            .e-con-inner>.elementor-widget-divider,
                            .e-con>.elementor-widget-divider {
                                width: var(--container-widget-width, 100%);
                                --flex-grow: var(--container-widget-flex-grow)
                            }
                        </style>
                        <div class="elementor-divider">
                            <span class="elementor-divider-separator">
                            </span>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-9462209 elementor-widget elementor-widget-wp-widget-woocommerce_products"
                    data-id="9462209" data-element_type="widget"
                    data-widget_type="wp-widget-woocommerce_products.default">
                    <div class="elementor-widget-container">
                        <div class="woocommerce widget_products">
                            <ul class="product_list_widget">
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-0058317"
            data-id="0058317" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-99c836e elementor-widget elementor-widget-heading"
                    data-id="99c836e" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <span class="elementor-heading-title elementor-size-default">Mua Nhiều</span>
                    </div>
                </div>
                <div class="elementor-element elementor-element-2e7ff1d elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                    data-id="2e7ff1d" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-divider">
                            <span class="elementor-divider-separator">
                            </span>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-66cff4e elementor-widget elementor-widget-wp-widget-woocommerce_products"
                    data-id="66cff4e" data-element_type="widget"
                    data-widget_type="wp-widget-woocommerce_products.default">
                    <div class="elementor-widget-container">
                        <div class="woocommerce widget_products">
                            <ul class="product_list_widget">
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-1e90c85"
            data-id="1e90c85" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-75f05d2 elementor-widget elementor-widget-heading"
                    data-id="75f05d2" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <span class="elementor-heading-title elementor-size-default">Nổi Bật</span>
                    </div>
                </div>
                <div class="elementor-element elementor-element-3f8d19d elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                    data-id="3f8d19d" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-divider">
                            <span class="elementor-divider-separator">
                            </span>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-bb6fc81 elementor-widget elementor-widget-wp-widget-woocommerce_products"
                    data-id="bb6fc81" data-element_type="widget"
                    data-widget_type="wp-widget-woocommerce_products.default">
                    <div class="elementor-widget-container">
                        <div class="woocommerce widget_products">
                            <ul class="product_list_widget">
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-1e90c85"
            data-id="1e90c85" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-75f05d2 elementor-widget elementor-widget-heading"
                    data-id="75f05d2" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <span class="elementor-heading-title elementor-size-default">Giảm giá</span>
                    </div>
                </div>
                <div class="elementor-element elementor-element-3f8d19d elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                    data-id="3f8d19d" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-divider">
                            <span class="elementor-divider-separator">
                            </span>
                        </div>
                    </div>
                </div>
                <div class="elementor-element elementor-element-bb6fc81 elementor-widget elementor-widget-wp-widget-woocommerce_products"
                    data-id="bb6fc81" data-element_type="widget"
                    data-widget_type="wp-widget-woocommerce_products.default">
                    <div class="elementor-widget-container">
                        <div class="woocommerce widget_products">
                            <ul class="product_list_widget">
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>
                                <li>

                                    <a href="/product/vinakoi-tropical-vibra-bites/">
                                        <img width="300" height="300"
                                            src="/assets/wp-content/uploads/2023/06/Hikari®-Tropical-Vibra-Bites™-73g-300x300.jpg"
                                            class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
                                            alt="VinaKoi Tropical Vibra Bites - 73g" decoding="async"
                                            sizes="(max-width: 300px) 100vw, 300px" /> <span
                                            class="product-title">VinaKoi® Tropical Vibra Bites™</span>
                                    </a>

                                    <div class="star-rating"><span style="width:0%">Được xếp hạng
                                            <strong class="rating">0</strong> 5 sao</span></div>
                                    <span class="woocommerce-Price-amount amount"><bdi>98.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                    &ndash; <span
                                        class="woocommerce-Price-amount amount"><bdi>858.000<span
                                                class="woocommerce-Price-currencySymbol">&#8363;</span></bdi></span>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<section
    class="elementor-section elementor-top-section elementor-element elementor-element-7f054e6 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="7f054e6" data-element_type="section"
    data-settings="{&quot;jet_parallax_layout_list&quot;:[],&quot;background_background&quot;:&quot;classic&quot;}">
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-18b1b87"
            data-id="18b1b87" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-6e9faad css_tieu_footer elementor-widget elementor-widget-heading"
                    data-id="6e9faad" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <span class="elementor-heading-title elementor-size-default">THỨC ĂN VINAKOI-
                            Thức ăn thú cưng cao cấp đến từ Nhật Bản</span>
                    </div>
                </div>
                <div class="elementor-element elementor-element-5104ea2 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                    data-id="5104ea2" data-element_type="widget" data-widget_type="icon-list.default">
                    <div class="elementor-widget-container">
                        <link rel="stylesheet"
                            href="/assets/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css">
                        <ul class="elementor-icon-list-items">
                            <li class="elementor-icon-list-item">
                                <span class="elementor-icon-list-text"><b> Địa chỉ</b>: Q12, TP.HCM </span>
                            </li>
                            <li class="elementor-icon-list-item">
                                <a href="tel:0999999999">

                                    <span class="elementor-icon-list-text"><b> Hotline</b>: 0962 980
                                        263</span>
                                </a>
                            </li>
                            <li class="elementor-icon-list-item">
                                <a href="mailto::vinakoi@gmail.com">

                                    <span class="elementor-icon-list-text"><b>Email</b>:
                                        vinakoi@gmail.com</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-8b8cf10"
            data-id="8b8cf10" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-cd85711 css_tieu_footer elementor-widget elementor-widget-heading"
                    data-id="cd85711" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <span class="elementor-heading-title elementor-size-default">Chính sách - Điều
                            khoản</span>
                    </div>
                </div>
                <div class="elementor-element elementor-element-56dce87 elementor-widget elementor-widget-text-editor"
                    data-id="56dce87" data-element_type="widget" data-widget_type="text-editor.default">
                    <div class="elementor-widget-container">
                        <p><span style="color: #ffffff;"><a style="color: #ffffff;"
                                    href="/chinh-sach/">Chính sách bảo
                                    hành</a></span></p>
                        <p><span style="color: #ffffff;"><a style="color: #ffffff;"
                                    href="/chinh-sach/">Chính sách đổi trả
                                </a></span></p>
                        <p><span style="color: #ffffff;"><a style="color: #ffffff;"
                                    href="/chinh-sach/">Chính sách bảo
                                    mật</a></span></p>
                        <p><a href="/contact"><span
                                    style="color: #ffffff;">Thông tin liên hệ</span></a></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-be27333"
            data-id="be27333" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-7795f81 elementor-widget elementor-widget-text-editor"
                    data-id="7795f81" data-element_type="widget" data-widget_type="text-editor.default">
                    <div class="elementor-widget-container">
                        <a href="//www.dmca.com/Protection/Status.aspx?ID=da5734f1-4877-4420-b82b-9f6cdbd8abef"
                            title="DMCA.com Protection Status" class="dmca-badge"> <img
                                src="https://images.dmca.com/Badges/dmca-badge-w100-2x1-02.png?ID=da5734f1-4877-4420-b82b-9f6cdbd8abef"
                                alt="DMCA.com Protection Status" /></a>
                        <script src="https://images.dmca.com/Badges/DMCABadgeHelper.min.js"> </script>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section
    class="elementor-section elementor-top-section elementor-element elementor-element-086bf8b elementor-section-boxed elementor-section-height-default elementor-section-height-default"
    data-id="086bf8b" data-element_type="section"
    data-settings="{&quot;jet_parallax_layout_list&quot;:[],&quot;background_background&quot;:&quot;classic&quot;}">
    <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7036e0b"
            data-id="7036e0b" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-772fb47 elementor-widget elementor-widget-heading"
                    data-id="772fb47" data-element_type="widget" data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <p class="elementor-heading-title elementor-size-default">Copyright 2025 © Thức
                            Ăn VINAKOI. All Rights Reserved.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</div>
